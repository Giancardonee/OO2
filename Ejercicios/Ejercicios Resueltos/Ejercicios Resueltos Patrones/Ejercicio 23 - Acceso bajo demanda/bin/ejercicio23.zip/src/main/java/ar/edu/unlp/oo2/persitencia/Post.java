package ar.edu.unlp.oo2.persitencia;

public class Post {
	
	private String text;
	
	public Post(String aText) {
		this.text = aText;
	}
	
	public String getText() {
		return this.text;
	}

}
